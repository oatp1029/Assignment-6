/*
* Title: Whale Fun
* Program Summary: Whale Fun enables the user to type in some human text, and have it spoken/displayed on the screen to them. Animations add to the fun of the program.
* Key Program Elements Utilized: querySelector, addEventListener, arrays, loops, nested loops, .push(), .join(), callback function, target.value, SpeechSynthesisUtterance(), window.speechSynthesis.speak();
    
    
    
    
    
            Arrays, Loops, parseInt, setTimeout(), location.href, document.location.reload(), Switch Staements, Return, charAt, .getDay(), Variables, use of document.getElementById with a variety of attributes (ex. the .value, .style.display, .style.width, etc.), a variety of Data Types, If ... Else If ... Else statements, Functions, Arithmetic Operators. HTML/CSS syntax utilized includes a HTML to PDF conversion, a detailed sitemap, a table, a feedback form, a menu, social media icons, and contact buttons.
    */




    function inputtovowels(inputted) {
      document.getElementById('originalPhrase').disabled = false;
      let resultarray = [];
      let input = inputted;
      let vowels = ['a', 'e', 'i', ' o', 'u'];
      let result;


      for (i = 0; i < input.length; i++) {

        for (j = 0; j < vowels.length; j++) {

          if (input[i] === vowels[j]) { // this is saying if each character of i includes each character of 2nd array - j

            if (input[i] === "e") {
              resultarray.push('ee');

            } else if (input[i] === "u") {
              resultarray.push('uu');

            } else {
              resultarray.push(input[i]);
            }
          }
        }
      }
      result = resultarray.join("").toUpperCase();
      return result;
    }









    document.querySelector("textarea").addEventListener("input", events => { // Is run every time value is changed.
      let getvalue = events.target.value.toLowerCase();
      if (inputtovowels(getvalue) === '') {
        document.getElementById('whaletalk').innerText = 'There are no vowels in your text, yet. Keep typing, and include some vowels!';
      }

      else {
        document.getElementById('whaletalk').innerText = inputtovowels(getvalue);
      }

    });



    document.getElementById('speakbtn').addEventListener("click", () => { // !!!!parameter is made blank. might have to put 'event'

      // freeze the input box (disable it), disable the button using the while it runs, and then stopped running - allow for new input and button again.


      let synth = window.speechSynthesis;
      let msg = new SpeechSynthesisUtterance("Your whale text is as follows:         " + document.getElementById('whaletalk').innerText.toLowerCase());
     

     synth.speak(msg);
  
            msg.addEventListener('start', function () {
          
                    
                  if (synth.speaking) {
          
              document.getElementById('originalPhrase').disabled = true;
          
                  }
                 
            });
              
                                 
          msg.addEventListener("end", (event) => {
          
          document.getElementById('originalPhrase').disabled = false;
          
          
          
            
          });


      
                       
                      
      
    });





function whalefacts () {
  let whale = []
}



// SpeechSynthesis.speaking Read only A boolean value that returns true if an utterance is currently in the process of being spoken — even if SpeechSynthesis is in a paused state.
// so while speech synthesis is speaking, then we disable the input box......








// objects, while (do while?)


// Idea: Every time sound button is pressed, we give them a didyou know whale fact which comes from an object's key value pairs.
// Sound button - when its clicked its a loop - every time its clicked the variable is set to 1, and if its clicked while the variable is set to 1 it wont start over and run.

// loop - every 10 seconds, keep running until all facts are exhausted and completed -> pick a fact from an object!!!! so we use objects.
// event listenersafter functions







// we take the text from javascript, put it to text to speech api and make it talk in whale talk on the website for all viewers.
// for loop we say for each time we say e  or u we go where the character is at and we replace
// we double the e and u appearance, no vowels to constants, we capitalize, use arrays and loops to iterate through all of the text
//translate to sanother lasnguage
//check for certain words
//perrson can try to see what the result is, and guess, then we show them the write and wrong letters and the correct rsult and give them an accuracy score
//whale facts on site
//dolphin or fish checker, whale vs beluga whale, fish, dog, cat translator
// avg life expectency ... give them facts at each step of the process ...they have to guess the result correctly to morve on the stepgive them more facts (up to 3) until they lost like 3 times

//.toUppercase()
//vowel check 
//https://developer.twitter.com/en/docs/twitter-for-websites/tweet-button/overview



// SpeechSynthesis.speaking Read only A boolean value that returns true if an utterance is currently in the process of being spoken — even if SpeechSynthesis is in a paused state.
// so while speech synthesis is speaking, then we disable the input box......








// objects, while (do while?)


// Idea: Every time sound button is pressed, we give them a didyou know whale fact which comes from an object's key value pairs.
// Sound button - when its clicked its a loop - every time its clicked the variable is set to 1, and if its clicked while the variable is set to 1 it wont start over and run.

// loop - every 10 seconds, keep running until all facts are exhausted and completed -> pick a fact from an object!!!! so we use objects.
// event listenersafter functions







// we take the text from javascript, put it to text to speech api and make it talk in whale talk on the website for all viewers.
// for loop we say for each time we say e  or u we go where the character is at and we replace
// we double the e and u appearance, no vowels to constants, we capitalize, use arrays and loops to iterate through all of the text
//translate to sanother lasnguage
//check for certain words
//perrson can try to see what the result is, and guess, then we show them the write and wrong letters and the correct rsult and give them an accuracy score
//whale facts on site
//dolphin or fish checker, whale vs beluga whale, fish, dog, cat translator
// avg life expectency ... give them facts at each step of the process ...they have to guess the result correctly to morve on the stepgive them more facts (up to 3) until they lost like 3 times

//.toUppercase()
//vowel check 
//https://developer.twitter.com/en/docs/twitter-for-websites/tweet-button/overview