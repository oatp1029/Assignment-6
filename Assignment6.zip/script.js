/*
* Title: Whale Fun
* Program Summary: Whale Fun enables the user to type in some human text, and have it spoken/displayed on the screen to them. Animations add to the fun of the program.
* Key Program Elements Utilized: 





        Arrays, Loops, parseInt, setTimeout(), location.href, document.location.reload(), Switch Staements, Return, charAt, .getDay(), Variables, use of document.getElementById with a variety of attributes (ex. the .value, .style.display, .style.width, etc.), a variety of Data Types, If ... Else If ... Else statements, Functions, Arithmetic Operators. HTML/CSS syntax utilized includes a HTML to PDF conversion, a detailed sitemap, a table, a feedback form, a menu, social media icons, and contact buttons.
*/





let input = '';




















// we take the text from javascript, put it to text to speech api and make it talk in whale talk on the website for all viewers.
// for loop we say for each time we say e  or u we go where the character is at and we replace
// we double the e and u appearance, no vowels to constants, we capitalize, use arrays and loops to iterate through all of the text
//translate to sanother lasnguage
//check for certain words
//perrson can try to see what the result is, and guess, then we show them the write and wrong letters and the correct rsult and give them an accuracy score
//whale facts on site
//dolphin or fish checker, whale vs beluga whale, fish, dog, cat translator
// avg life expectency ... give them facts at each step of the process ...they have to guess the result correctly to morve on the stepgive them more facts (up to 3) until they lost like 3 times

//.toUppercase()
//vowel check 
// https://www.educative.io/answers/how-to-convert-text-to-speech-in-javascript
